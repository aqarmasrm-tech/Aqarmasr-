# عقار مصر للمقاولات والتوريدات

الموقع الرسمي لشركة **عقار مصر** — مقاولات عامة، بنية تحتية، مياه وصرف صحي، أعمال كهروميكانيكية وتوريدات.

## التشغيل المحلي

افتح `index.html` مباشرة في المتصفح، أو شغّل سيرفر بسيط:

```bash
npx serve .
# أو
python3 -m http.server 8080
```

## النشر على GitHub Pages (الأفضل)

1. أنشئ Repository جديد على GitHub باسم مثلاً `aqar-masr` أو `aqarmasr-website`
2. ارفع محتويات هذا المجلد (خصوصاً `index.html`)
3. ادخل **Settings → Pages**
4. Source: **Deploy from a branch** → Branch: `main` → Folder: `/ (root)`
5. احفظ → بعد دقيقة هتلاقي اللينك:
   `https://YOUR_USERNAME.github.io/REPO_NAME`

## ملاحظات تقنية

- Single-file website (كل شيء مدمج)
- Dark institutional theme + gold
- GSAP + ScrollTrigger + Three.js + Particle field + Magnetic interactions
- RTL كامل
- يحترم `prefers-reduced-motion`

---

© عقار مصر للمقاولات والتوريدات
